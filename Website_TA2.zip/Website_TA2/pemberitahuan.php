<?php
session_start(); 
//mendapatkan id tanaman dari url
$id_tanaman = $_GET['id'];


if(isset($_SESSION['keranjang'][$id_tanaman]))
{
	$_SESSION['keranjang'][$id_tanaman]+= 1;
}

else
{
	$_SESSION['keranjang'][$id_tanaman] = 1;
}






 

//echo "<pre>";
//print_r($_SESSION);
//echo "</pre>"
//data dikirim ke halaman keranjang
echo "<script>alert('Nutrisi Sekarang adalah 950 PPM, disarankan untuk menambahkan 200 PPM');</script>";
echo "<script>location='graphic.php';</script>";
 ?>

