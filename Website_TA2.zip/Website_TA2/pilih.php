<?php
session_start(); 
//mendapatkan id tanaman dari url
$id_tanaman = $_GET['id'];


if(isset($_SESSION['keranjang'][$id_tanaman]))
{
	$_SESSION['keranjang'][$id_tanaman]+= 1;
}

else
{
	$_SESSION['keranjang'][$id_tanaman] = 1;
}






 

//echo "<pre>";
//print_r($_SESSION);
//echo "</pre>"
//data dikirim ke halaman keranjang
echo "<script>alert('Tanaman telah dipilih, lanjutkan pemilihan Fitur');</script>";
echo "<script>location='pilihfitur.php';</script>";

 ?>

