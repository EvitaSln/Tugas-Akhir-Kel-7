<h2>Selamat datang Admin VegShop</h2>
<pre><?php print_r($_SESSION); ?></pre>
